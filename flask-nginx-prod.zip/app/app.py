from flask import Flask
from flask_caching import Cache
import time
import json

with open('../config/config.json') as f:
    config = json.load(f)

app = Flask(__name__)
cache = Cache(app, config={'CACHE_TYPE': 'SimpleCache', 'CACHE_DEFAULT_TIMEOUT': 60})

@app.route('/')
@cache.cached()
def index():
    return f"Site {config['domains'][0]} en ligne ! Heure : {time.ctime()}"

@app.route('/refresh_cache')
def refresh_cache():
    cache.clear()
    return "Cache purg� !"

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=config['flask_port'])
