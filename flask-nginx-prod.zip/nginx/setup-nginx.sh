#!/bin/bash
CONFIG_FILE="../config/config.json"
DOMAINS=$(jq -r '.domains[]' $CONFIG_FILE)
FLASK_PORT=$(jq -r '.flask_port' $CONFIG_FILE)
EMAIL=$(jq -r '.email' $CONFIG_FILE)

sudo apt update
sudo apt install -y nginx certbot python3-certbot-nginx brotli jq

sudo mkdir -p /var/www/html
sudo cp ../html/404.html /var/www/html/404.html
sudo cp ../html/50x.html /var/www/html/50x.html

for SITE in $DOMAINS; do
sudo tee /etc/nginx/sites-available/$SITE > /dev/null <<EOL
server {
    listen 80;
    server_name $SITE www.$SITE;
    if (\$host ~* ^www\.(.*)\$) { return 301 https://\$1\$request_uri; }
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl http2;
    server_name $SITE www.$SITE;
    ssl_certificate /etc/letsencrypt/live/$SITE/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$SITE/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    gzip on;
    gzip_types text/plain text/css application/javascript application/json image/svg+xml;
    gzip_min_length 256;
    brotli on;
    brotli_types text/plain text/css application/javascript application/json image/svg+xml;
    brotli_comp_level 6;
    location / {
        proxy_pass http://127.0.0.1:$FLASK_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    location ~* \\.(jpg|jpeg|png|gif|ico|css|js|svg|woff2?)\$ {
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }
    location ~* \\.(html|php)\$ {
        expires 1h;
        add_header Cache-Control "private, no-transform";
    }
    error_page 404 /404.html;
    error_page 500 502 503 504 /50x.html;
    location = /404.html { root /var/www/html; internal; }
    location = /50x.html { root /var/www/html; internal; }
    http2_push_preload on;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header Host \$host;
}
EOL
sudo ln -sf /etc/nginx/sites-available/$SITE /etc/nginx/sites-enabled/
done

sudo nginx -t
sudo systemctl reload nginx

sudo certbot --nginx $(printf -- "-d %s " $DOMAINS) --email $EMAIL --agree-tos --no-eff-email --redirect
